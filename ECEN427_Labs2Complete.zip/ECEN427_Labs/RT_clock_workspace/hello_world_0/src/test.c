#include "xgpio.h"          // Provides access to PB GPIO driver.
#include <stdio.h>          // xil_printf and so forth.
#include "platform.h"       // Enables caching and other system stuff.
#include "mb_interface.h"   // provides the microblaze interrupt enables, etc.
#include "xintc_l.h"        // Provides handy macros for the interrupt controller.
#include <stdint.h>

#define CLOCK_INCREMENT_VALUE 100 // because CPU running at 100MHz, a timer of 100 = 1 second

// values that define when the clock should roll over to MIN_VAL
#define MAX_SECOND_VALUE 60
#define MAX_MINUTE_VALUE 60
#define MAX_HOUR_VALUE 25
#define MIN_VAL 0

// buttons on the board are rearranged as follows:
//        (UP)
//   (HR) (MN) (SC)
//        (DN)
// The mask definitions help to identify which of the buttons
// are being held down at any particular time
#define BTN_CENTER_MASK 0x01
#define BTN_RIGHT_MASK 0x02
#define BTN_DOWN_MASK 0x04
#define BTN_LEFT_MASK 0x08
#define BTN_UP_MASK 0x10

#define DEBOUNCE_VALUE 5 // the max value of the debounce counter. 10ms * 5 = 50ms
#define AUTO_INC_TIMER_VALUE 100 // max value of the button 1 second value
#define AUTO_INC_HALF_VALUE (AUTO_INC_TIMER_VALUE / 2) // half the time
// an enumeration of our states
enum clockControl_st_t {
	counting_st,			// No buttons are held, inc seconds
	debounce_st,			// Button(s) held down. Debounce any change
	check_st,				// inc/dec time depending on buttons held
	auto_inc_timer_st,		// a timer that inc time based on how long buttons held
	update_clock_st			// updates the clock on the console

} currentState = counting_st;

XGpio gpLED;  // This is a handle for the LED GPIO block.
XGpio gpPB;   // This is a handle for the push-button GPIO block.

uint32_t count = 0;					// timer to inc seconds every second
uint32_t count_debounce = 0;		// timer to debounce buttons
uint32_t currentButtonState = 0;	// the currently held buttons
uint32_t prevButtonState = 0;		// the buttons that were held when exit debounce_st
uint8_t inc_timer = 0;				// timer to inc/dec time within the auto_inc_timer_st
uint8_t first_time = 1;				// "first time" within auto_inc_timer_st.

int8_t seconds = 0;
int8_t minutes = 0;
int8_t hours = 0;

// moore output, or actions taken while within the state
void clockControl_tick() {
	switch(currentState) {
	case counting_st:
		count++;
		break;
	case debounce_st:
		count_debounce++;
		break;
	case auto_inc_timer_st:
		inc_timer++;
		break;
	case update_clock_st:
		xil_printf("\r%02d:%02d:%02d", hours, minutes, seconds);
		break;
	default:
		break;
	}

	// mealy outputs or actions taken between states
	switch(currentState) {
	case counting_st:
		if (currentButtonState != 0) {  // if any button is being pressed
			currentState = debounce_st; // move to debounce state
		}
		else if (count >= CLOCK_INCREMENT_VALUE){ // straight forward yes?
			seconds++; 								// update the seconds
			currentState = update_clock_st;			// move to the update clock state
			count = MIN_VAL;						// reset count timer

			// check for any rollovers and handle accordingly
			if(seconds >= MAX_SECOND_VALUE){ // if seconds went too high
				minutes++;
				seconds = MIN_VAL;
			}

			if(minutes >= MAX_MINUTE_VALUE){ // if minutes went too high
				hours++;
				minutes = MIN_VAL;
			}

			if(hours >= MAX_HOUR_VALUE){	// if hours went too high
				hours = MIN_VAL;
			}
		}
		else { // stay in this state
			currentState = counting_st;
		}
		break;
	case debounce_st:
		// if debounce value is greater than max value and buttons are being pressed
		if (count_debounce >= DEBOUNCE_VALUE && currentButtonState != 0) {
			prevButtonState = currentButtonState; // save which buttons are being held
			currentState = check_st;			  // move to the checking state
			count_debounce = 0;					  // reset the timer yo
		}
		else if (currentButtonState == 0) {	// if no buttons are being held
			currentState = counting_st;		// go back to the counting state
		}
		else { // else stay in this state
			currentState = debounce_st;
		}
		break;
	case check_st:
		// checks to see which buttons were held when exited the debounce state

		// this if statement deals with when the up button was pressed
			if ((prevButtonState & BTN_UP_MASK) == BTN_UP_MASK) {
				if ((prevButtonState & BTN_RIGHT_MASK) == BTN_RIGHT_MASK) { // checks if second button was held
					seconds++;
				}
				if ((prevButtonState & BTN_CENTER_MASK) == BTN_CENTER_MASK) { // checks if minute button was held
					minutes++;
				}
				if ((prevButtonState & BTN_LEFT_MASK) == BTN_LEFT_MASK) { // checks if hour button was held
					hours++;
				}
			}
			// this if statement deals with when the down button was pressed
			if ((prevButtonState & BTN_DOWN_MASK) == BTN_DOWN_MASK) {
				if ((prevButtonState & BTN_RIGHT_MASK) == BTN_RIGHT_MASK) {	// checks if second button was held
					seconds--;
				}
				if ((prevButtonState & BTN_CENTER_MASK) == BTN_CENTER_MASK) { // checks if minute button was held
					minutes--;
				}
				if ((prevButtonState & BTN_LEFT_MASK) == BTN_LEFT_MASK) { // checks if hour button was held
					hours--;
				}
			}

			// deals with when values of time roll below the MIN_VAL
			if(seconds < MIN_VAL){ 				// if seconds became negative
				seconds = MAX_SECOND_VALUE - 1; // set it to the max value minus 1
			}

			if(minutes < MIN_VAL){				// same but for minutes
				minutes = MAX_MINUTE_VALUE - 1;
			}

			if(hours < MIN_VAL){				// same but for hours
				hours = MAX_HOUR_VALUE - 1;
			}

			if(seconds >= MAX_SECOND_VALUE){ 	// rolls over to MIN_VAL when inc higher than max value
				seconds = MIN_VAL;				// sets seconds to MIN_VAL
			}

			if(minutes >= MAX_MINUTE_VALUE){	// same but for minutes
				minutes = MIN_VAL;
			}

			if(hours >= MAX_HOUR_VALUE){		// same but for hours
				hours = MIN_VAL;
			}

			currentState = update_clock_st;		// move to the update state

		break;
	case auto_inc_timer_st:
		// if buttons held for 1 second and first time in this state then go to check_st & reset timers
		if (inc_timer >= AUTO_INC_TIMER_VALUE && currentButtonState == prevButtonState && first_time) {
			currentState = check_st;
			first_time = 0;
			inc_timer = 0;
		}
		// every half second, if buttons pushed are still the same and not first time through
		// go to check_st and reset timers
		if (inc_timer % AUTO_INC_HALF_VALUE == 0 && currentButtonState == prevButtonState && !first_time) {
			currentState = check_st;
			first_time = 0;
			inc_timer = 0;
		}
		// if buttons are released then go to counting_st and reset timer/first time flag
		else if (currentButtonState == 0) {
			first_time = 1;
			inc_timer = 0;
			currentState = counting_st;
		}
		// when user changes buttons reset first time flag and inc timer and go to debounce_st
		else if (currentButtonState != prevButtonState) {
			first_time = 1;
			inc_timer = 0;
			currentState = debounce_st;
		}
		else {
			//stay in this state
		}
		break;
	// updates/redraws the clock
	case update_clock_st:
		//if no buttons pushed go to counting_st
		if (currentButtonState == 0) {
			currentState = counting_st;
		}
		// if button state has changed go to debounce_st
		else if (currentButtonState != prevButtonState ) {
			currentState = debounce_st;
		}
		// if still holding same buttons go to auto_inc_timer_st
		else {
			currentState = auto_inc_timer_st;
		}
		break;
	// nada
	default:
		break;
	}
}


// This is invoked in response to a timer interrupt.
// It does 2 things: 1) debounce switches, and 2) advances the time.
void timer_interrupt_handler() {
	// invokes our state machine
	clockControl_tick();
}

// This is invoked each time there is a change in the button state (result of a push or a bounce).
void pb_interrupt_handler() {
	// Clear the GPIO interrupt.
	XGpio_InterruptGlobalDisable(&gpPB);                // Turn off all PB interrupts for now.
	currentButtonState = XGpio_DiscreteRead(&gpPB, 1);  // Get the current state of the buttons.
	// You need to do something here.

	XGpio_InterruptClear(&gpPB, 0xFFFFFFFF);            // Ack the PB interrupt.
	XGpio_InterruptGlobalEnable(&gpPB);                 // Re-enable PB interrupts.
}

// Main interrupt handler, queries the interrupt controller to see what peripheral
// fired the interrupt and then dispatches the corresponding interrupt handler.
// This routine acks the interrupt at the controller level but the peripheral
// interrupt must be ack'd by the dispatched interrupt handler.
// Question: Why is the timer_interrupt_handler() called after ack'ing the interrupt controller
// but pb_interrupt_handler() is called before ack'ing the interrupt controller?
void interrupt_handler_dispatcher(void* ptr) {
	int intc_status = XIntc_GetIntrStatus(XPAR_INTC_0_BASEADDR);
	// Check the FIT interrupt first.
	if (intc_status & XPAR_FIT_TIMER_0_INTERRUPT_MASK){
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_FIT_TIMER_0_INTERRUPT_MASK);
		timer_interrupt_handler();
	}
	// Check the push buttons.
	if (intc_status & XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK){
		pb_interrupt_handler();
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK);
	}
}

int main (void) {
    init_platform();
    // Initialize the GPIO peripherals.
    int success;
    print("hello world\n\r");
    success = XGpio_Initialize(&gpPB, XPAR_PUSH_BUTTONS_5BITS_DEVICE_ID);
    // Set the push button peripheral to be inputs.
    XGpio_SetDataDirection(&gpPB, 1, 0x0000001F);
    // Enable the global GPIO interrupt for push buttons.
    XGpio_InterruptGlobalEnable(&gpPB);
    // Enable all interrupts in the push button peripheral.
    XGpio_InterruptEnable(&gpPB, 0xFFFFFFFF);

    microblaze_register_handler(interrupt_handler_dispatcher, NULL);
    XIntc_EnableIntr(XPAR_INTC_0_BASEADDR,
    		(XPAR_FIT_TIMER_0_INTERRUPT_MASK | XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK));
    XIntc_MasterEnable(XPAR_INTC_0_BASEADDR);
    microblaze_enable_interrupts();

    while(1);  // Program never ends.

    cleanup_platform();

    return 0;
}
