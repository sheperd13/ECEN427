
#include <stdio.h>
#include "platform.h"
#include <stdint.h>

void print(char *str);

#define REPEAT_COUNT 15 // the number of sequence iterations
#define START_SEQ 1     // Fib starts with 1 + 1

int main()
{
    init_platform(); //initilizes something

    uint32_t var1 = START_SEQ; //fib starts with 1 + 1
    uint32_t var2 = START_SEQ; //fib starts with 1 + 1
    uint32_t var3 = 0; 		   // the result of var1 and var2
    uint32_t i = 0;    		   // variable used for the while loop
    xil_printf("%d\n\r",var1); // print statement
    xil_printf("%d\n\r",var2); // print statement

    // loops through 15 iterations of the fib seq
    while(i < REPEAT_COUNT) {
    	var3 = var1 + var2; 		// adds up the previous numbers
    	xil_printf("%d\n\r",var3); 	// prints them out
    	var1 = var2; // save previous values
    	var2 = var3; // save previous values
    	i++; 		 // iterate up
    }

    cleanup_platform();

    return 0;
}
