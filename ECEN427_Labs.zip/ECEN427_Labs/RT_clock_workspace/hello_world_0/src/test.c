#include "xgpio.h"          // Provides access to PB GPIO driver.
#include <stdio.h>          // xil_printf and so forth.
#include "platform.h"       // Enables caching and other system stuff.
#include "mb_interface.h"   // provides the microblaze interrupt enables, etc.
#include "xintc_l.h"        // Provides handy macros for the interrupt controller.
#include <stdint.h>

#define CLOCK_INCREMENT_VALUE 100
#define MAX_SECOND_VALUE 60
#define MAX_MINUTE_VALUE 60
#define MAX_HOUR_VALUE 25
#define MIN_VAL 0

#define BTN_CENTER_MASK 0x01
#define BTN_RIGHT_MASK 0x02
#define BTN_DOWN_MASK 0x04
#define BTN_LEFT_MASK 0x08
#define BTN_UP_MASK 0x10

enum clockControl_st_t {
	counting_st,
	debounce_st,
	check_st,
	wait_release_st,
	update_clock_st

} currentState = counting_st;

XGpio gpLED;  // This is a handle for the LED GPIO block.
XGpio gpPB;   // This is a handle for the push-button GPIO block.

uint32_t count = 0;
uint32_t count_debounce = 0;
uint32_t currentButtonState = 0;
uint32_t prevButtonState = 0;

int32_t seconds = 0;
int32_t minutes = 0;
int32_t hours = 0;

void clockControl_tick() {
	switch(currentState) {
	case counting_st:
		count++;
		break;
	case debounce_st:
		count_debounce++;
		break;
	case wait_release_st:
		break;
	case update_clock_st:
		xil_printf("\r%02d:%02d:%02d", hours, minutes, seconds);
		break;
	default:
		break;
	}

	// transitions
	switch(currentState) {
	case counting_st:
		if (currentButtonState != 0) {
			currentState = debounce_st;
		}
		else if(count >= CLOCK_INCREMENT_VALUE){
			seconds++;
			currentState = update_clock_st;
			count = 0;

			if(seconds >= MAX_SECOND_VALUE){
				minutes++;
				seconds = 0;
			}

			if(minutes >= MAX_MINUTE_VALUE){
				hours++;
				minutes = 0;
			}

			if(hours >= MAX_HOUR_VALUE){
				hours = 0;
			}
		}
		else {
			currentState = counting_st;
		}
		break;
	case debounce_st:
		if (count_debounce >= 7 && currentButtonState != 0) {
			prevButtonState = currentButtonState;
			currentState = check_st;
			count_debounce = 0;
		}
		else if (currentButtonState == 0) {
			currentState = counting_st;
		}
		else {
			currentState = debounce_st;
		}
		break;
	case check_st:
		if (currentButtonState != prevButtonState) { // button's changed
			if ((prevButtonState & BTN_UP_MASK) == BTN_UP_MASK) {
				if ((prevButtonState & BTN_RIGHT_MASK) == BTN_RIGHT_MASK) {
					seconds++;
				}
				if ((prevButtonState & BTN_CENTER_MASK) == BTN_CENTER_MASK) {
					minutes++;
				}
				if ((prevButtonState & BTN_LEFT_MASK) == BTN_LEFT_MASK) {
					hours++;
				}
			}
			if ((prevButtonState & BTN_DOWN_MASK) == BTN_DOWN_MASK) {
				if ((prevButtonState & BTN_RIGHT_MASK) == BTN_RIGHT_MASK) {
					seconds--;

				}
				if ((prevButtonState & BTN_CENTER_MASK) == BTN_CENTER_MASK) {
					minutes--;
				}
				if ((prevButtonState & BTN_LEFT_MASK) == BTN_LEFT_MASK) {
					hours--;
				}
			}
			currentState = update_clock_st;

			if(seconds < MIN_VAL){
				seconds = MAX_SECOND_VALUE - 1;
			}

			if(minutes < MIN_VAL){
				minutes = MAX_MINUTE_VALUE - 1;
			}

			if(hours < MIN_VAL){
				hours = MAX_HOUR_VALUE - 1;
			}

			if(seconds >= MAX_SECOND_VALUE){
				seconds = MIN_VAL;
			}

			if(minutes >= MAX_MINUTE_VALUE){
				minutes = MIN_VAL;
			}

			if(hours >= MAX_HOUR_VALUE){
				hours = MIN_VAL;
			}

		}

		break;
	case wait_release_st:
		if (currentButtonState == 0) {
			currentState = counting_st;
		}
		else {
			currentState = wait_release_st;
		}
		break;
	case update_clock_st:
		if (currentButtonState == 0) {
			currentState = counting_st;
		}
		else {
			currentState = debounce_st;
		}
		break;
	default:
		break;
	}
}


// This is invoked in response to a timer interrupt.
// It does 2 things: 1) debounce switches, and 2) advances the time.
void timer_interrupt_handler() {
	clockControl_tick();
}

// This is invoked each time there is a change in the button state (result of a push or a bounce).
void pb_interrupt_handler() {
	// Clear the GPIO interrupt.
	XGpio_InterruptGlobalDisable(&gpPB);                // Turn off all PB interrupts for now.
	currentButtonState = XGpio_DiscreteRead(&gpPB, 1);  // Get the current state of the buttons.
	// You need to do something here.

	XGpio_InterruptClear(&gpPB, 0xFFFFFFFF);            // Ack the PB interrupt.
	XGpio_InterruptGlobalEnable(&gpPB);                 // Re-enable PB interrupts.
}

// Main interrupt handler, queries the interrupt controller to see what peripheral
// fired the interrupt and then dispatches the corresponding interrupt handler.
// This routine acks the interrupt at the controller level but the peripheral
// interrupt must be ack'd by the dispatched interrupt handler.
// Question: Why is the timer_interrupt_handler() called after ack'ing the interrupt controller
// but pb_interrupt_handler() is called before ack'ing the interrupt controller?
void interrupt_handler_dispatcher(void* ptr) {
	int intc_status = XIntc_GetIntrStatus(XPAR_INTC_0_BASEADDR);
	// Check the FIT interrupt first.
	if (intc_status & XPAR_FIT_TIMER_0_INTERRUPT_MASK){
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_FIT_TIMER_0_INTERRUPT_MASK);
		timer_interrupt_handler();
	}
	// Check the push buttons.
	if (intc_status & XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK){
		pb_interrupt_handler();
		XIntc_AckIntr(XPAR_INTC_0_BASEADDR, XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK);
	}
}

int main (void) {
    init_platform();
    // Initialize the GPIO peripherals.
    int success;
    print("hello world\n\r");
    success = XGpio_Initialize(&gpPB, XPAR_PUSH_BUTTONS_5BITS_DEVICE_ID);
    // Set the push button peripheral to be inputs.
    XGpio_SetDataDirection(&gpPB, 1, 0x0000001F);
    // Enable the global GPIO interrupt for push buttons.
    XGpio_InterruptGlobalEnable(&gpPB);
    // Enable all interrupts in the push button peripheral.
    XGpio_InterruptEnable(&gpPB, 0xFFFFFFFF);

    microblaze_register_handler(interrupt_handler_dispatcher, NULL);
    XIntc_EnableIntr(XPAR_INTC_0_BASEADDR,
    		(XPAR_FIT_TIMER_0_INTERRUPT_MASK | XPAR_PUSH_BUTTONS_5BITS_IP2INTC_IRPT_MASK));
    XIntc_MasterEnable(XPAR_INTC_0_BASEADDR);
    microblaze_enable_interrupts();

    while(1);  // Program never ends.

    cleanup_platform();

    return 0;
}
